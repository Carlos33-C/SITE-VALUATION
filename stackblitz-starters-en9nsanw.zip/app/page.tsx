"use client";
export default function HomePage() {
  return (
    <div>
      <section className="border-b border-linha">
        <div className="max-w-5xl mx-auto px-5 pt-14 pb-12">
          <p className="text-[12px] tabular uppercase tracking-wide text-selo mb-4">
            Metodologia fundamentalista · Dados públicos da B3
          </p>
          <h1 className="font-editorial text-[34px] sm:text-[42px] leading-[1.15] max-w-2xl mb-5">
            Descubra o preço justo de qualquer ação da bolsa
          </h1>
          <p className="text-[16px] text-tinta-suave max-w-xl leading-relaxed mb-8">
            Digite um ticker e receba, em segundos, um valuation completo:
            Graham, Bazin, DCF e P/L de referência — combinados em um parecer único.
          </p>
          <form action="" onSubmit={(e) => {
            e.preventDefault();
            const input = (e.target as HTMLFormElement).querySelector('input') as HTMLInputElement;
            const ticker = input.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
            if (ticker.length >= 4) window.location.href = `/acao/${ticker}`;
          }} className="flex flex-col sm:flex-row gap-2.5 max-w-lg">
            <input
              type="text"
              placeholder="Digite o ticker — ex: PETR4"
              maxLength={7}
              autoFocus
              className="flex-1 text-[16px] px-4 py-3 bg-white border border-linha-forte focus:outline-none focus:border-selo tabular"
            />
            <button type="submit" className="text-[14px] font-medium px-6 py-3 bg-selo text-white hover:bg-selo-hover transition-colors whitespace-nowrap">
              Analisar ação
            </button>
          </form>
          <div className="flex flex-wrap gap-2 mt-4">
            {["PETR4","VALE3","ITUB4","WEGE3","BBAS3"].map((t) => (
              <a key={t} href={`/acao/${t}`}
                className="text-[12px] tabular px-2.5 py-1 border border-linha text-tinta-suave hover:border-selo hover:text-selo transition-colors">
                {t}
              </a>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-5 py-8">
        <div className="border border-dashed border-linha-forte flex items-center justify-center text-[11px] text-tinta-suave uppercase tracking-wide" style={{minHeight:"90px"}}>
          Publicidade
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-5 py-6">
        <p className="text-[12px] uppercase tracking-wide text-tinta-suave mb-6">Como a análise é montada</p>
        <div className="grid sm:grid-cols-3 gap-px bg-linha border border-linha">
          {[
            { n:"01", t:"Dados de mercado", d:"Preço, LPA, VPA e indicadores buscados em tempo real a partir de fontes públicas da B3." },
            { n:"02", t:"Quatro metodologias", d:"Graham, Bazin, DCF simplificado e P/L de referência calculados de forma independente." },
            { n:"03", t:"Parecer consolidado", d:"Os resultados viram um parecer em linguagem clara, com pontos fortes e de atenção." },
          ].map((item) => (
            <div key={item.n} className="bg-papel p-6">
              <p className="font-editorial text-[22px] text-selo mb-2 tabular">{item.n}</p>
              <p className="text-[14px] font-medium mb-1.5">{item.t}</p>
              <p className="text-[13px] text-tinta-suave leading-relaxed">{item.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-5 py-10">
        <p className="text-[12px] uppercase tracking-wide text-tinta-suave mb-5">Para entender melhor</p>
        <div className="grid sm:grid-cols-3 gap-6">
          {[
            { href:"/o-que-e-valuation", t:"O que é valuation", d:"Entenda o conceito por trás de calcular o valor justo de uma empresa negociada em bolsa." },
            { href:"/formula-de-graham", t:"Fórmula de Graham", d:"A fórmula clássica de Benjamin Graham para valor intrínseco, explicada passo a passo." },
            { href:"/metodo-bazin", t:"Método de Bazin", d:"Como o preço-teto de Décio Bazin ajuda investidores de dividendos." },
          ].map((item) => (
            <a key={item.href} href={item.href} className="group border border-linha hover:border-selo transition-colors p-5">
              <p className="text-[14px] font-medium mb-1 group-hover:text-selo transition-colors">{item.t}</p>
              <p className="text-[13px] text-tinta-suave leading-relaxed">{item.d}</p>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}
import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Análise de Valuation — Preço justo de ações da B3",
    template: "%s — Análise de Valuation",
  },
  description:
    "Calcule o valor justo de qualquer ação da B3 com metodologia fundamentalista: Graham, Bazin, DCF e P/L, com indicadores e parecer detalhado.",
};

function Header() {
  return (
    <header className="border-b border-linha bg-papel sticky top-0 z-30">
      <div className="max-w-5xl mx-auto px-5 py-3.5 flex items-center justify-between gap-6">
        <a href="/" className="flex items-center gap-2.5 shrink-0">
          <span className="w-2.5 h-2.5 bg-selo inline-block" />
          <span className="font-editorial text-[19px] leading-none">
            Análise de Valuation
          </span>
        </a>
        <nav className="hidden sm:flex items-center gap-5 text-[13px] text-tinta-suave shrink-0">
          <a href="/o-que-e-valuation" className="hover:text-tinta transition-colors">Metodologia</a>
          <a href="/formula-de-graham" className="hover:text-tinta transition-colors">Fórmulas</a>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="border-t border-linha mt-16">
      <div className="max-w-5xl mx-auto px-5 py-10">
        <div className="grid sm:grid-cols-3 gap-8 text-[13px]">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="w-2 h-2 bg-selo inline-block" />
              <span className="font-editorial text-[16px]">Análise de Valuation</span>
            </div>
            <p className="text-tinta-suave leading-relaxed max-w-xs">
              Valuation fundamentalista de ações da B3, calculado a partir de dados públicos de mercado.
            </p>
          </div>
          <div>
            <p className="text-tinta-suave uppercase tracking-wide text-[11px] mb-3">Metodologia</p>
            <ul className="space-y-2 text-tinta-suave">
              <li><a href="/o-que-e-valuation" className="hover:text-selo transition-colors">O que é valuation</a></li>
              <li><a href="/formula-de-graham" className="hover:text-selo transition-colors">Fórmula de Graham</a></li>
              <li><a href="/metodo-bazin" className="hover:text-selo transition-colors">Método de Bazin</a></li>
            </ul>
          </div>
          <div>
            <p className="text-tinta-suave uppercase tracking-wide text-[11px] mb-3">Institucional</p>
            <ul className="space-y-2 text-tinta-suave">
              <li><a href="/politica-de-privacidade" className="hover:text-selo transition-colors">Política de privacidade</a></li>
              <li><a href="/termos-de-uso" className="hover:text-selo transition-colors">Termos de uso</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-linha mt-8 pt-6">
          <p className="text-[11.5px] text-tinta-suave leading-relaxed max-w-3xl">
            As informações apresentadas têm caráter exclusivamente informativo e educacional.
            Não constituem recomendação de compra ou venda de nenhum ativo.
          </p>
          <p className="text-[11.5px] text-tinta-suave mt-3">© 2026 Análise de Valuation.</p>
        </div>
      </div>
    </footer>
  );
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className="h-full antialiased">
      <body className="min-h-full flex flex-col bg-papel text-tinta">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
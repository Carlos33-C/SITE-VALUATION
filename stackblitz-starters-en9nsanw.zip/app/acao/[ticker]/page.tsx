"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";

// ============ TIPOS ============
interface DadosAtivo {
  ticker: string; nome: string; setor: string | null;
  precoAtual: number; variacaoDia: number; atualizadoEm: string;
  lpa: number | null; vpa: number | null; pl: number | null; pvp: number | null;
  dy12m: number | null; roe: number | null; margemLiquida: number | null;
  margemEbitda: number | null; dividaEbitda: number | null;
}

type Classificacao = "muito-descontada" | "descontada" | "justa" | "esticada" | "muito-esticada" | "indeterminado";

interface ResultadoMetodo {
  metodo: string; descricao: string; valorJusto: number | null;
  upside: number | null; disponivel: boolean; motivoIndisponivel?: string;
}

interface IndicadorAnalise {
  chave: string; titulo: string; valor: number | null;
  unidade: "x" | "%" | "R$"; referencia: string;
  status: "bom" | "neutro" | "atencao" | "indisponivel"; comentario: string;
}

interface ResultadoValuation {
  ativo: DadosAtivo; metodos: ResultadoMetodo[];
  precoJustoConsenso: number | null; upsideConsenso: number | null;
  margemSeguranca: number | null; classificacao: Classificacao;
  scorePontuacao: number; indicadores: IndicadorAnalise[];
  parecer: string; pontosAtencao: string[]; pontosFortes: string[];
}

// ============ BUSCA DE DADOS ============
const TICKERS_TESTE = new Set(["PETR4", "VALE3", "MGLU3", "ITUB4"]);

async function buscarAtivo(tickerBruto: string): Promise<DadosAtivo> {
  const ticker = tickerBruto.trim().toUpperCase();

  if (!TICKERS_TESTE.has(ticker)) {
    throw new Error(
      `Sem token configurado, apenas PETR4, VALE3, MGLU3 e ITUB4 estão disponíveis. Crie uma conta gratuita em brapi.dev para liberar todos os tickers.`
    );
  }

  const url = `https://brapi.dev/api/quote/${ticker}?fundamental=true&modules=defaultKeyStatistics,financialData,summaryProfile&dividends=true`;
  const resposta = await fetch(url);

  if (!resposta.ok) throw new Error(`Falha ao buscar ${ticker} (status ${resposta.status}).`);

  const json = await resposta.json();
  const r = json?.results?.[0];
  if (!r) throw new Error(`Ticker ${ticker} não encontrado na B3.`);

  const dy12m = (() => {
    const divs = r.dividendsData?.cashDividends;
    if (!divs || !r.regularMarketPrice) return null;
    const umAno = Date.now() - 365 * 24 * 60 * 60 * 1000;
    const total = divs
      .filter((d: any) => new Date(d.paymentDate).getTime() >= umAno)
      .reduce((s: number, d: any) => s + (d.rate || 0), 0);
    return total > 0 ? (total / r.regularMarketPrice) * 100 : null;
  })();

  const norm = (v: any) => (v == null ? null : Math.abs(v) <= 1 ? v * 100 : v);
  const roeRaw = r.financialData?.returnOnEquity ?? r.defaultKeyStatistics?.returnOnEquity ?? null;

  return {
    ticker: r.symbol,
    nome: r.longName || r.shortName || r.symbol,
    setor: r.summaryProfile?.sector ?? null,
    precoAtual: r.regularMarketPrice,
    variacaoDia: r.regularMarketChangePercent ?? 0,
    atualizadoEm: r.regularMarketTime ?? new Date().toISOString(),
    lpa: r.earningsPerShare ?? null,
    vpa: r.defaultKeyStatistics?.bookValue ?? null,
    pl: r.priceEarnings ?? null,
    pvp: r.defaultKeyStatistics?.priceToBook ?? null,
    dy12m,
    roe: roeRaw !== null ? norm(roeRaw) : null,
    margemLiquida: norm(r.financialData?.profitMargins),
    margemEbitda: norm(r.financialData?.ebitdaMargins),
    dividaEbitda: r.financialData?.debtToEquity ?? null,
  };
}

// ============ MOTOR DE VALUATION ============
function graham(a: DadosAtivo): ResultadoMetodo {
  if (!a.lpa || a.lpa <= 0 || !a.vpa || a.vpa <= 0)
    return { metodo: "Fórmula de Graham", descricao: "√(22,5 × LPA × VPA)", valorJusto: null, upside: null, disponivel: false, motivoIndisponivel: "LPA ou VPA indisponível/negativo." };
  const v = Math.sqrt(22.5 * a.lpa * a.vpa);
  return { metodo: "Fórmula de Graham", descricao: "√(22,5 × LPA × VPA)", valorJusto: v, upside: ((v - a.precoAtual) / a.precoAtual) * 100, disponivel: true };
}

function bazin(a: DadosAtivo): ResultadoMetodo {
  const div = a.dy12m !== null ? (a.dy12m / 100) * a.precoAtual : null;
  if (!div || div <= 0)
    return { metodo: "Método de Bazin", descricao: "Dividendo 12m ÷ 6%", valorJusto: null, upside: null, disponivel: false, motivoIndisponivel: "Sem histórico de dividendos suficiente." };
  const v = div / 0.06;
  return { metodo: "Método de Bazin", descricao: "Dividendo 12m ÷ 6%", valorJusto: v, upside: ((v - a.precoAtual) / a.precoAtual) * 100, disponivel: true };
}

function plReferencia(a: DadosAtivo): ResultadoMetodo {
  if (!a.lpa || a.lpa <= 0)
    return { metodo: "P/L justo (referência)", descricao: "LPA × 12x", valorJusto: null, upside: null, disponivel: false, motivoIndisponivel: "LPA indisponível ou negativo." };
  const v = a.lpa * 12;
  return { metodo: "P/L justo (referência)", descricao: "LPA × 12x", valorJusto: v, upside: ((v - a.precoAtual) / a.precoAtual) * 100, disponivel: true };
}

function dcf(a: DadosAtivo): ResultadoMetodo {
  if (!a.lpa || a.lpa <= 0)
    return { metodo: "DCF simplificado", descricao: "5 anos, desconto 12% a.a.", valorJusto: null, upside: null, disponivel: false, motivoIndisponivel: "LPA indisponível ou negativo." };
  let vp = 0, f = a.lpa;
  for (let i = 1; i <= 5; i++) { f *= 1.05; vp += f / Math.pow(1.12, i); }
  const vt = (f * 1.03) / (0.12 - 0.03);
  const v = vp + vt / Math.pow(1.12, 5);
  return { metodo: "DCF simplificado", descricao: "5 anos, desconto 12% a.a.", valorJusto: v, upside: ((v - a.precoAtual) / a.precoAtual) * 100, disponivel: true };
}

function montarIndicadores(a: DadosAtivo): IndicadorAnalise[] {
  const mk = (chave: string, titulo: string, valor: number | null, unidade: "x"|"%"|"R$", referencia: string,
    ehBom: boolean, ehNeutro: boolean, cBom: string, cNeutro: string, cAtencao: string): IndicadorAnalise => ({
    chave, titulo, valor, unidade, referencia,
    status: valor === null ? "indisponivel" : ehBom ? "bom" : ehNeutro ? "neutro" : "atencao",
    comentario: valor === null ? "Dado indisponível para este ativo." : ehBom ? cBom : ehNeutro ? cNeutro : cAtencao,
  });

  return [
    mk("pl", "P/L — Preço sobre Lucro", a.pl, "x", "Referência: quanto menor, mais barata",
      a.pl !== null && a.pl > 0 && a.pl < 10, a.pl !== null && a.pl >= 10 && a.pl < 18,
      "Múltiplo baixo em relação à média histórica do mercado (~12x-14x).",
      "Múltiplo dentro da faixa considerada razoável pelo mercado.",
      "Múltiplo elevado — o mercado já precifica crescimento futuro relevante."),
    mk("pvp", "P/VP — Preço sobre Valor Patrimonial", a.pvp, "x", "Referência: abaixo de 1,5x indica desconto",
      a.pvp !== null && a.pvp < 1, a.pvp !== null && a.pvp < 2,
      "Ação negociada abaixo do valor patrimonial — sinal clássico de desconto.",
      "Prêmio moderado sobre o patrimônio contábil.",
      "Prêmio elevado sobre o valor patrimonial — exige justificativa de crescimento."),
    mk("dy", "Dividend Yield (12 meses)", a.dy12m, "%", "Comparar sempre com a Selic/CDI vigente",
      a.dy12m !== null && a.dy12m > 8, a.dy12m !== null && a.dy12m > 4,
      "Yield elevado — verifique se é sustentável ou pontual.",
      "Yield moderado, dentro da média histórica da bolsa brasileira.",
      "Yield baixo — empresa pode estar reinvestindo o lucro em crescimento."),
    mk("roe", "ROE — Retorno sobre Patrimônio", a.roe, "%", "Referência: acima de 15% é considerado forte",
      a.roe !== null && a.roe > 15, a.roe !== null && a.roe > 8,
      "Empresa gera retorno forte sobre o capital próprio dos acionistas.",
      "Retorno moderado sobre o patrimônio.",
      "Retorno baixo sobre o patrimônio — atenção à eficiência do capital."),
    mk("ml", "Margem líquida", a.margemLiquida, "%", "Varia por setor — compare com pares",
      a.margemLiquida !== null && a.margemLiquida > 15, a.margemLiquida !== null && a.margemLiquida > 5,
      "Margem líquida robusta — bom sinal de eficiência operacional.",
      "Margem líquida dentro de uma faixa comum de mercado.",
      "Margem líquida apertada — modelo de negócio sensível a custos."),
    mk("divida", "Dívida líquida / EBITDA", a.dividaEbitda, "x", "Alerta: acima de 3x merece atenção",
      a.dividaEbitda !== null && a.dividaEbitda < 1.5, a.dividaEbitda !== null && a.dividaEbitda < 3,
      "Endividamento baixo em relação à geração de caixa operacional.",
      "Alavancagem moderada, dentro de patamar administrável.",
      "Alavancagem elevada — risco financeiro maior em cenários de estresse."),
  ];
}

function calcularValuation(a: DadosAtivo): ResultadoValuation {
  const metodos = [graham(a), bazin(a), plReferencia(a), dcf(a)];
  const disp = metodos.filter(m => m.disponivel && m.valorJusto !== null);
  const consenso = disp.length > 0 ? disp.reduce((s, m) => s + (m.valorJusto as number), 0) / disp.length : null;
  const upsideConsenso = consenso !== null ? ((consenso - a.precoAtual) / a.precoAtual) * 100 : null;
  const margemSeguranca = consenso !== null ? ((consenso - a.precoAtual) / consenso) * 100 : null;

  const classificacao: Classificacao =
    upsideConsenso === null ? "indeterminado"
    : upsideConsenso >= 30 ? "muito-descontada"
    : upsideConsenso >= 10 ? "descontada"
    : upsideConsenso >= -10 ? "justa"
    : upsideConsenso >= -30 ? "esticada"
    : "muito-esticada";

  const inds = montarIndicadores(a);
  const validos = inds.filter(i => i.status !== "indisponivel");
  const score = validos.length === 0 ? 50 : Math.round(
    validos.reduce((s, i) => s + (i.status === "bom" ? 100 : i.status === "neutro" ? 60 : 20), 0) / validos.length
  );

  const fortes = inds.filter(i => i.status === "bom").map(i => i.comentario);
  const atencao = inds.filter(i => i.status === "atencao").map(i => i.comentario);

  const rotulos: Record<Classificacao, string> = {
    "muito-descontada": "está significativamente descontada em relação ao valor justo estimado",
    "descontada": "está moderadamente descontada em relação ao valor justo estimado",
    "justa": "está sendo negociada próxima ao valor justo estimado",
    "esticada": "apresenta sinais de estar precificada acima do valor justo estimado",
    "muito-esticada": "está significativamente acima do valor justo estimado",
    "indeterminado": "não possui dados suficientes para uma conclusão confiável",
  };

  let parecer = `${a.ticker} ${rotulos[classificacao]}.`;
  if (fortes.length > 0) parecer += ` Entre os pontos favoráveis: ${fortes.slice(0, 2).join(" ")}`;
  if (atencao.length > 0) parecer += ` Como ponto de atenção: ${atencao[0].charAt(0).toLowerCase()}${atencao[0].slice(1)}`;
  if (upsideConsenso !== null) {
    parecer += ` O consenso dos métodos aponta ${upsideConsenso >= 0 ? "upside" : "downside"} de ${Math.abs(upsideConsenso).toFixed(1)}% em relação ao preço atual — use como referência de estudo, nunca como recomendação de compra ou venda.`;
  }

  return { ativo: a, metodos, precoJustoConsenso: consenso, upsideConsenso, margemSeguranca,
    classificacao, scorePontuacao: score, indicadores: inds, parecer, pontosFortes: fortes, pontosAtencao: atencao };
}

// ============ HELPERS VISUAIS ============
const ROTULO: Record<Classificacao, string> = {
  "muito-descontada": "Muito descontada", "descontada": "Descontada",
  "justa": "Próxima do valor justo", "esticada": "Esticada",
  "muito-esticada": "Muito esticada", "indeterminado": "Dados insuficientes",
};

const COR: Record<Classificacao, string> = {
  "muito-descontada": "text-selo bg-selo-fraco", "descontada": "text-selo bg-selo-fraco",
  "justa": "text-dourado bg-dourado-fraco", "esticada": "text-alerta bg-alerta-fraco",
  "muito-esticada": "text-risco bg-risco-fraco", "indeterminado": "text-tinta-suave bg-linha",
};

const ST: Record<string, string> = {
  bom: "text-selo bg-selo-fraco", neutro: "text-dourado bg-dourado-fraco",
  atencao: "text-alerta bg-alerta-fraco", indisponivel: "text-tinta-suave bg-linha",
};

const ST_LABEL: Record<string, string> = {
  bom: "Favorável", neutro: "Neutro", atencao: "Atenção", indisponivel: "Indisponível",
};

const moeda = (v: number | null) => v === null ? "—" : v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const pct = (v: number | null, d = 1) => v === null ? "—" : `${v > 0 ? "+" : ""}${v.toFixed(d)}%`;
const fmt = (v: number | null, u: string) => v === null ? "—" : u === "R$" ? moeda(v) : `${v.toFixed(1)}${u === "%" ? "%" : "x"}`;

function Anuncio() {
  return (
    <div className="border border-dashed border-linha-forte flex items-center justify-center text-[11px] text-tinta-suave uppercase tracking-wide my-8" style={{ minHeight: "90px" }}>
      Publicidade
    </div>
  );
}

// ============ PÁGINA ============
export default function PaginaAtivo() {
  const params = useParams();
  const ticker = (params?.ticker as string) || "";
  const [resultado, setResultado] = useState<ResultadoValuation | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    if (!ticker) return;
    setCarregando(true);
    setErro(null);
    buscarAtivo(ticker)
      .then(a => setResultado(calcularValuation(a)))
      .catch(e => setErro(e instanceof Error ? e.message : "Erro ao buscar dados."))
      .finally(() => setCarregando(false));
  }, [ticker]);

  if (carregando) {
    return (
      <div className="max-w-3xl mx-auto px-5 py-20 text-center">
        <p className="text-[15px] text-tinta-suave">Calculando valuation de {ticker.toUpperCase()}...</p>
      </div>
    );
  }

  if (erro || !resultado) {
    return (
      <div className="max-w-2xl mx-auto px-5 py-16 text-center">
        <p className="font-editorial text-[22px] mb-3">Não foi possível carregar {ticker.toUpperCase()}</p>
        <p className="text-[14px] text-tinta-suave mb-8 leading-relaxed">{erro}</p>
        <a href="/" className="inline-block text-[13px] px-5 py-2.5 bg-selo text-white hover:bg-selo-hover transition-colors">
          Voltar ao início
        </a>
      </div>
    );
  }

  const r = resultado;
  const pos = Math.max(2, Math.min(98, ((r.upsideConsenso ?? 0) + 40) * (100 / 80)));
  const dataFmt = new Date(r.ativo.atualizadoEm).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });

  return (
    <div className="max-w-3xl mx-auto px-5 py-10">
      <div className="mb-6 flex gap-2 max-w-sm">
        <input
          type="text" placeholder="Outro ticker..." maxLength={7}
          className="flex-1 text-[13px] px-3 py-1.5 bg-white border border-linha-forte focus:outline-none focus:border-selo tabular"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              const v = (e.target as HTMLInputElement).value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
              if (v.length >= 4) window.location.href = `/acao/${v}`;
            }
          }}
        />
        <a href="/" className="text-[12px] px-3 py-1.5 bg-papel border border-linha text-tinta-suave hover:border-selo transition-colors whitespace-nowrap">
          ← Início
        </a>
      </div>

      {/* PAINEL PRINCIPAL */}
      <div className="border border-linha bg-white">
        <div className="p-5 border-b border-linha flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 flex items-center justify-center bg-selo-fraco text-selo text-[12px] font-medium">
              {r.ativo.ticker.slice(0, 4)}
            </div>
            <div>
              <p className="text-[18px] font-medium tabular">{r.ativo.ticker}</p>
              <p className="text-[12px] text-tinta-suave">{r.ativo.nome}{r.ativo.setor ? ` · ${r.ativo.setor}` : ""}</p>
            </div>
          </div>
          <span className={`text-[12px] font-medium px-3 py-1.5 ${COR[r.classificacao]}`}>
            {ROTULO[r.classificacao]}
          </span>
        </div>

        <div className="grid sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-linha border-b border-linha">
          <div className="p-5">
            <p className="text-[10.5px] uppercase tracking-wide text-tinta-suave mb-1.5">Preço atual</p>
            <p className="text-[22px] font-medium tabular">{moeda(r.ativo.precoAtual)}</p>
            <p className={`text-[12px] tabular mt-1 ${r.ativo.variacaoDia >= 0 ? "text-selo" : "text-risco"}`}>
              {pct(r.ativo.variacaoDia)} no dia
            </p>
          </div>
          <div className="p-5">
            <p className="text-[10.5px] uppercase tracking-wide text-tinta-suave mb-1.5">Preço justo (consenso)</p>
            <p className="text-[22px] font-medium tabular">{moeda(r.precoJustoConsenso)}</p>
            <p className={`text-[12px] tabular mt-1 ${(r.upsideConsenso ?? 0) >= 0 ? "text-selo" : "text-risco"}`}>
              {r.upsideConsenso !== null ? `${pct(r.upsideConsenso)} de ${r.upsideConsenso >= 0 ? "upside" : "downside"}` : "Sem dados"}
            </p>
          </div>
          <div className="p-5">
            <p className="text-[10.5px] uppercase tracking-wide text-tinta-suave mb-1.5">Pontuação fundamentalista</p>
            <p className="text-[22px] font-medium tabular">{r.scorePontuacao}<span className="text-[13px] text-tinta-suave">/100</span></p>
            <p className="text-[12px] text-tinta-suave mt-1">
              Com base em {r.indicadores.filter(i => i.status !== "indisponivel").length} indicadores
            </p>
          </div>
        </div>

        <div className="p-5">
          <div className="flex justify-between text-[10.5px] uppercase tracking-wide text-tinta-suave mb-2">
            <span>Muito esticada</span><span>Valor justo</span><span>Muito descontada</span>
          </div>
          <div className="relative h-2 bg-linha rounded-full">
            <div className="absolute h-full w-full rounded-full" style={{ background: "linear-gradient(90deg,#8a2f2f 0%,#9c5a2e 30%,#a9822f 50%,#2f4d3f 75%,#2f4d3f 100%)" }} />
            <div className="absolute top-1/2 w-3 h-3 bg-white border-2 border-tinta rounded-full" style={{ left: `${pos}%`, transform: "translate(-50%,-50%)" }} />
          </div>
          {r.margemSeguranca !== null && (
            <p className="text-[12px] text-tinta-suave mt-3 text-center">
              Margem de segurança de <strong className="tabular text-tinta">{r.margemSeguranca.toFixed(1)}%</strong> sobre o preço justo consolidado
            </p>
          )}
        </div>
      </div>

      <Anuncio />

      {/* MÉTODOS */}
      <h2 className="font-editorial text-[20px] mb-4">Métodos de valuation aplicados</h2>
      <div className="border border-linha bg-white divide-y divide-linha">
        {r.metodos.map(m => (
          <div key={m.metodo} className="p-5 flex flex-wrap items-center justify-between gap-3">
            <div className="max-w-md">
              <p className="text-[13px] font-medium mb-0.5">{m.metodo}</p>
              <p className="text-[12px] text-tinta-suave">{m.disponivel ? m.descricao : m.motivoIndisponivel}</p>
            </div>
            <div className="text-right">
              <p className="text-[17px] font-medium tabular">{m.disponivel ? moeda(m.valorJusto) : "—"}</p>
              {m.disponivel && m.upside !== null && (
                <p className={`text-[12px] tabular mt-0.5 ${m.upside >= 0 ? "text-selo" : "text-risco"}`}>{pct(m.upside)}</p>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* INDICADORES */}
      <h2 className="font-editorial text-[20px] mb-4 mt-10">Indicadores fundamentalistas</h2>
      <div className="grid sm:grid-cols-2 gap-px bg-linha border border-linha">
        {r.indicadores.map(ind => (
          <div key={ind.chave} className="bg-white p-5">
            <div className="flex items-start justify-between gap-2 mb-2">
              <p className="text-[12.5px] font-medium leading-snug">{ind.titulo}</p>
              <span className={`text-[10.5px] font-medium px-2 py-0.5 whitespace-nowrap ${ST[ind.status]}`}>
                {ST_LABEL[ind.status]}
              </span>
            </div>
            <p className="text-[20px] font-medium tabular mb-1">{fmt(ind.valor, ind.unidade)}</p>
            <p className="text-[11px] text-tinta-suave mb-1.5">{ind.referencia}</p>
            <p className="text-[12px] text-tinta-suave leading-relaxed">{ind.comentario}</p>
          </div>
        ))}
      </div>

      {/* PARECER */}
      <h2 className="font-editorial text-[20px] mb-4 mt-10">Parecer fundamentalista</h2>
      <div className="border border-linha bg-white p-6">
        <div className="flex items-center gap-2.5 mb-5 pb-5 border-b border-linha">
          <div className="w-8 h-8 flex items-center justify-center bg-tinta text-papel text-[10px] font-medium rounded-full">AV</div>
          <div>
            <p className="text-[13px] font-medium">Parecer fundamentalista</p>
            <p className="text-[11.5px] text-tinta-suave">Metodologia quantitativa · Atualizado em {dataFmt}</p>
          </div>
        </div>
        <p className="font-editorial text-[16px] leading-[1.8] border-l-2 border-selo pl-4">{r.parecer}</p>

        {(r.pontosFortes.length > 0 || r.pontosAtencao.length > 0) && (
          <div className="grid sm:grid-cols-2 gap-6 mt-6 pt-6 border-t border-linha">
            {r.pontosFortes.length > 0 && (
              <div>
                <p className="text-[10.5px] uppercase tracking-wide text-selo mb-2">Pontos favoráveis</p>
                {r.pontosFortes.map((p, i) => (
                  <p key={i} className="text-[12.5px] text-tinta-suave leading-relaxed flex gap-2 mb-1.5">
                    <span className="text-selo">+</span>{p}
                  </p>
                ))}
              </div>
            )}
            {r.pontosAtencao.length > 0 && (
              <div>
                <p className="text-[10.5px] uppercase tracking-wide text-alerta mb-2">Pontos de atenção</p>
                {r.pontosAtencao.map((p, i) => (
                  <p key={i} className="text-[12.5px] text-tinta-suave leading-relaxed flex gap-2 mb-1.5">
                    <span className="text-alerta">−</span>{p}
                  </p>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <Anuncio />
    </div>
  );
}
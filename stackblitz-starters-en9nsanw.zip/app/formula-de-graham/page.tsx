export default function FormulaDeGraham() {
  return (
    <div className="max-w-3xl mx-auto px-5 py-12">
      <div className="mb-12">
        <p className="text-[12px] uppercase tracking-wide text-selo mb-4">Metodologia</p>
        <h1 className="font-editorial text-[40px] sm:text-[48px] leading-[1.15] mb-5">Fórmula de Graham</h1>
        <p className="text-[16px] text-tinta-suave leading-relaxed max-w-2xl">
          A fórmula de Benjamin Graham é uma das mais antigas e elegantes da análise fundamentalista. Simples, objetiva, e funciona para empresas com ciclos estáveis.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">A fórmula</h2>
        <div className="bg-papel border border-linha p-6 mb-6">
          <p className="text-[13px] text-tinta-suave mb-3">Valor justo = √(22,5 × LPA × VPA)</p>
          <p className="text-[12px] text-tinta-suave">
            Onde: LPA = Lucro Por Ação | VPA = Valor Patrimonial Por Ação
          </p>
        </div>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          Simples assim. Pegue dois números do balanço da empresa, multiplique por 22,5, tire a raiz quadrada, e pronto — você tem um valor justo teórico.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Por que 22,5?</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Graham originalmente usava premissas específicas: uma empresa com crescimento zero pagaria dividendos baseado em seu lucro, e você exigiria um retorno mínimo. Isso resultava em múltiplos máximos (P/L máximo de 15x, P/VP máximo de 1,5x).
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          A fórmula que usamos hoje é uma simplificação: se uma empresa "perfeita" (sem crescimento, alto retorno sobre patrimônio) valeria 15x o lucro E 1,5x o patrimônio, então o valor justo é a média geométrica desses dois — que resulta em 22,5 como constante.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          (Se você é técnico: é 15 × 1,5 = 22,5. A raiz quadrada "nivela" os dois múltiplos.)
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Exemplo prático</h2>
        <div className="bg-papel border border-linha p-6 mb-6">
          <p className="text-[13px] font-medium mb-3">Hipótese:</p>
          <p className="text-[13px] text-tinta-suave mb-2">LPA = R$ 2,00</p>
          <p className="text-[13px] text-tinta-suave mb-4">VPA = R$ 15,00</p>
          <p className="text-[13px] font-medium mb-2">Cálculo:</p>
          <p className="text-[13px] text-tinta-suave mb-2">√(22,5 × 2,00 × 15,00)</p>
          <p className="text-[13px] text-tinta-suave mb-2">= √(675)</p>
          <p className="text-[13px] text-tinta-suave mb-4">= R$ 25,98</p>
          <p className="text-[12px] text-tinta-suave border-t border-linha pt-4">
            Logo, uma ação com LPA de R$ 2,00 e VPA de R$ 15,00 teria um valor justo estimado de R$ 25,98.
          </p>
        </div>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Quando funciona bem</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Graham criou essa fórmula pensando em grandes bancos e indústrias que mudavam pouco: empresas com lucro previsível, patrimônio estável, sem surpresas drásticas.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          A fórmula funciona bem para:
        </p>
        <ul className="space-y-2 mb-4">
          <li className="flex gap-3">
            <span className="text-selo">•</span>
            <span className="text-[14px] text-tinta-suave">Bancos e instituições financeiras</span>
          </li>
          <li className="flex gap-3">
            <span className="text-selo">•</span>
            <span className="text-[14px] text-tinta-suave">Indústrias tradicionais com ciclos longos</span>
          </li>
          <li className="flex gap-3">
            <span className="text-selo">•</span>
            <span className="text-[14px] text-tinta-suave">Empresas de utilidade pública (água, energia)</span>
          </li>
          <li className="flex gap-3">
            <span className="text-selo">•</span>
            <span className="text-[14px] text-tinta-suave">Empresas com patrimônio contábil bem documentado</span>
          </li>
        </ul>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Quando não funciona</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Existem empresas modernas onde o patrimônio contábil é quase irrelevante — startups de software, plataformas de internet. Nesses casos, VPA é baixo ou negativo, e a fórmula quebra.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Além disso:
        </p>
        <ul className="space-y-2 mb-4">
          <li className="flex gap-3">
            <span className="text-alerta">−</span>
            <span className="text-[14px] text-tinta-suave">Não captura crescimento esperado — trata todas as empresas como se não crescessem</span>
          </li>
          <li className="flex gap-3">
            <span className="text-alerta">−</span>
            <span className="text-[14px] text-tinta-suave">Assume que lucro e patrimônio são estáveis — em empresas cíclicas (mineradoras, commodities), o lucro varia muito</span>
          </li>
          <li className="flex gap-3">
            <span className="text-alerta">−</span>
            <span className="text-[14px] text-tinta-suave">Usa múltiplos fixos que podem estar desatualizados em contextos de inflação ou taxas de juros muito diferentes</span>
          </li>
        </ul>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Margem de segurança</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Graham era obcecado com um conceito: margem de segurança. Ele não recomendava comprar uma ação só porque o preço era 5% abaixo do valor justo. Esperava uma margem maior.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          Sua regra prática: só comprar se o preço fosse 30-40% abaixo do valor justo calculado. Assim, mesmo que a fórmula estivesse errada, você ainda teria lucro. É um trabalho de proteção contra os erros inevitáveis do valuation.
        </p>
      </div>

      <div className="pb-12">
        <h2 className="font-editorial text-[28px] mb-5">Próximos passos</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <a href="/o-que-e-valuation" className="group border border-linha hover:border-selo transition-colors p-5">
            <p className="text-[14px] font-medium mb-1 group-hover:text-selo transition-colors">Voltar: O que é valuation</p>
            <p className="text-[13px] text-tinta-suave">Revise os conceitos principais.</p>
          </a>
          <a href="/metodo-bazin" className="group border border-linha hover:border-selo transition-colors p-5">
            <p className="text-[14px] font-medium mb-1 group-hover:text-selo transition-colors">Próximo: Método de Bazin</p>
            <p className="text-[13px] text-tinta-suave">Para quem investe em dividendos.</p>
          </a>
        </div>
        <div className="mt-6">
          <a href="/" className="text-[13px] px-5 py-2.5 bg-selo text-white hover:bg-selo-hover transition-colors inline-block">
            Analisar uma ação
          </a>
        </div>
      </div>
    </div>
  );
}
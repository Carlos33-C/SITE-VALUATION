export default function TermosDeUso() {
  return (
    <div className="max-w-3xl mx-auto px-5 py-12">
      <div className="mb-12">
        <p className="text-[12px] uppercase tracking-wide text-tinta-suave mb-4">Informações legais</p>
        <h1 className="font-editorial text-[40px] sm:text-[48px] leading-[1.15] mb-5">Termos de Uso</h1>
        <p className="text-[13px] text-tinta-suave">Última atualização: {new Date().toLocaleDateString("pt-BR")}</p>
      </div>

      <div className="space-y-10">
        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">1. Aceitação dos Termos</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Ao acessar e usar este site ("Análise de Valuation"), você concorda em aceitar e estar vinculado por estes Termos de Uso. Se você não concorda com estes termos, não use o site.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">2. Isenção de Responsabilidade</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            <strong className="text-tinta">IMPORTANTE:</strong> Este site é fornecido apenas para fins educacionais e informativos. O conteúdo não constitui:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Recomendação de investimento</li>
            <li>• Análise elaborada por profissional certificado</li>
            <li>• Aconselhamento financeiro ou jurídico</li>
            <li>• Oferta ou solicitação para comprar ou vender títulos</li>
          </ul>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Qualquer decisão de investimento deve ser baseada em sua própria análise e, idealmente, em consulta com um consultor financeiro qualificado.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">3. Precisão dos dados</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Os dados exibidos neste site (cotações, LPA, dividendos, etc.) vêm de APIs terceirizadas e podem conter:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Atrasos em relação aos dados em tempo real</li>
            <li>• Imprecisões ou erros de fonte</li>
            <li>• Falhas temporárias de conexão</li>
          </ul>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Recomendamos sempre verificar os dados através de fontes oficiais (como o site da B3 ou dos próprios bancos de investimento) antes de tomar decisões.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">4. Metodologia de Cálculo</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Os cálculos de valuation (Graham, Bazin, P/L, DCF) são baseados em premissas fixas e simplificadas:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Não capturam contexto individual de cada empresa</li>
            <li>• Não ajustam para ciclos econômicos</li>
            <li>• Usam dados históricos que podem não refletir o futuro</li>
            <li>• Podem estar muito errados em casos extremos</li>
          </ul>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Sempre considere esses números como ponto de partida para sua pesquisa, não como conclusão final.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">5. Uso do site</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Você concorda em usar o site apenas para fins legítimos e não:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Tentar hacker ou danificar o site</li>
            <li>• Usar bots ou scripts para coletar dados em larga escala</li>
            <li>• Transmitir vírus ou conteúdo prejudicial</li>
            <li>• Violação de leis de propriedade intelectual</li>
            <li>• Assediar ou ameaçar outros usuários</li>
          </ul>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">6. Propriedade Intelectual</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Todo o conteúdo deste site (textos, imagens, design, código) é protegido por leis de propriedade intelectual. Você pode ler e usar o conteúdo pessoalmente, mas não pode:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Copiar ou reproduzir conteúdo sem permissão</li>
            <li>• Vender ou distribuir conteúdo</li>
            <li>• Usar o conteúdo em um site ou aplicativo concorrente</li>
            <li>• Remover avisos de copyright ou propriedade intelectual</li>
          </ul>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">7. Links para terceiros</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Este site pode conter links para sites de terceiros (como brapi.dev, B3, bancos). Nós:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Não temos controle sobre esses sites</li>
            <li>• Não somos responsáveis pelo conteúdo ou políticas deles</li>
            <li>• Não endossamos necessariamente esses sites</li>
          </ul>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Verifique os termos de uso de qualquer site de terceiro antes de usar.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">8. Limitação de Responsabilidade</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Na medida permitida por lei, nós não somos responsáveis por: perdas financeiras, lucros perdidos, dados perdidos, ou qualquer dano indireto resultante do uso ou incapacidade de usar o site, mesmo que tenhamos sido avisados da possibilidade de tais danos.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">9. "Como está"</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            O site é fornecido "como está" sem garantias de qualquer tipo, expressas ou implícitas. Não garantimos que o site será: disponível 24/7, livre de erros, seguro de vírus, ou adequado para um propósito específico.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">10. Contexto de Investimento</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Investimento em ações envolve risco, incluindo a possibilidade de perda total do principal investido. Você reconhece que:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Valuation não prediz movimentos de preço de curto prazo</li>
            <li>• Uma ação pode estar "barata" e ficar mais barata ainda</li>
            <li>• Mudanças macroeconômicas podem invalidar qualquer análise</li>
            <li>• Diversificação é essencial</li>
          </ul>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Nunca invista dinheiro que você não pode perder.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">11. Modificações aos Termos</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Podemos modificar estes Termos de Uso a qualquer momento. Mudanças importantes serão publicadas nesta página. O uso contínuo do site após mudanças significa que você aceita os novos termos.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">12. Lei Aplicável</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Estes Termos de Uso são regidos pelas leis da República Federativa do Brasil, sem considerar seus conflitos de disposições legais.
          </p>
        </div>

        <div className="pb-8">
          <h2 className="font-editorial text-[24px] mb-4">13. Contato</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Se você tiver dúvidas sobre estes Termos de Uso, entre em contato conosco através do formulário de contato do site.
          </p>
        </div>
      </div>

      <div className="bg-alerta-fraco border border-alerta p-5 rounded">
        <p className="text-[12px] text-alerta font-medium mb-1">⚠ AVISO IMPORTANTE</p>
        <p className="text-[13px] text-tinta-suave">
          Valuation é uma ferramenta educacional. Não é recomendação de investimento. Consulte um profissional certificado antes de investir dinheiro real.
        </p>
      </div>
    </div>
  );
}
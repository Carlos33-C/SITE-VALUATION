import { buscarAtivo, AtivoNaoEncontradoError } from "../../lib/brapi";
import { calcularValuation } from "../../lib/valuation";
import type { ResultadoValuation, IndicadorAnalise, ResultadoMetodo, Classificacao } from "../../lib/types";

const ROTULO: Record<Classificacao, string> = {
  "muito-descontada": "Muito descontada",
  "descontada": "Descontada",
  "justa": "Próxima do valor justo",
  "esticada": "Esticada",
  "muito-esticada": "Muito esticada",
  "indeterminado": "Dados insuficientes",
};

const COR: Record<Classificacao, string> = {
  "muito-descontada": "text-selo bg-selo-fraco",
  "descontada": "text-selo bg-selo-fraco",
  "justa": "text-dourado bg-dourado-fraco",
  "esticada": "text-alerta bg-alerta-fraco",
  "muito-esticada": "text-risco bg-risco-fraco",
  "indeterminado": "text-tinta-suave bg-linha",
};

function moeda(v: number | null) {
  if (v === null) return "—";
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function pct(v: number | null, dec = 1) {
  if (v === null) return "—";
  return `${v > 0 ? "+" : ""}${v.toFixed(dec)}%`;
}

function fmt(v: number | null, u: IndicadorAnalise["unidade"]) {
  if (v === null) return "—";
  if (u === "R$") return moeda(v);
  return `${v.toFixed(1)}${u === "%" ? "%" : "x"}`;
}

const ST: Record<IndicadorAnalise["status"], string> = {
  bom: "text-selo bg-selo-fraco",
  neutro: "text-dourado bg-dourado-fraco",
  atencao: "text-alerta bg-alerta-fraco",
  indisponivel: "text-tinta-suave bg-linha",
};

const ST_LABEL: Record<IndicadorAnalise["status"], string> = {
  bom: "Favorável", neutro: "Neutro", atencao: "Atenção", indisponivel: "Indisponível",
};

function Painel({ r }: { r: ResultadoValuation }) {
  const pos = Math.max(2, Math.min(98, ((r.upsideConsenso ?? 0) + 40) * (100 / 80)));
  return (
    <div className="border border-linha bg-white">
      <div className="p-5 border-b border-linha flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 flex items-center justify-center bg-selo-fraco text-selo text-[12px] font-medium">
            {r.ativo.ticker.slice(0, 4)}
          </div>
          <div>
            <p className="text-[18px] font-medium tabular">{r.ativo.ticker}</p>
            <p className="text-[12px] text-tinta-suave">{r.ativo.nome}{r.ativo.setor ? ` · ${r.ativo.setor}` : ""}</p>
          </div>
        </div>
        <span className={`text-[12px] font-medium px-3 py-1.5 ${COR[r.classificacao]}`}>
          {ROTULO[r.classificacao]}
        </span>
      </div>

      <div className="grid sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-linha border-b border-linha">
        <div className="p-5">
          <p className="text-[10.5px] uppercase tracking-wide text-tinta-suave mb-1.5">Preço atual</p>
          <p className="text-[22px] font-medium tabular">{moeda(r.ativo.precoAtual)}</p>
          <p className={`text-[12px] tabular mt-1 ${r.ativo.variacaoDia >= 0 ? "text-selo" : "text-risco"}`}>
            {pct(r.ativo.variacaoDia)} no dia
          </p>
        </div>
        <div className="p-5">
          <p className="text-[10.5px] uppercase tracking-wide text-tinta-suave mb-1.5">Preço justo (consenso)</p>
          <p className="text-[22px] font-medium tabular">{moeda(r.precoJustoConsenso)}</p>
          <p className={`text-[12px] tabular mt-1 ${(r.upsideConsenso ?? 0) >= 0 ? "text-selo" : "text-risco"}`}>
            {r.upsideConsenso !== null ? `${pct(r.upsideConsenso)} de ${r.upsideConsenso >= 0 ? "upside" : "downside"}` : "Sem dados suficientes"}
          </p>
        </div>
        <div className="p-5">
          <p className="text-[10.5px] uppercase tracking-wide text-tinta-suave mb-1.5">Pontuação fundamentalista</p>
          <p className="text-[22px] font-medium tabular">{r.scorePontuacao}<span className="text-[13px] text-tinta-suave">/100</span></p>
          <p className="text-[12px] text-tinta-suave mt-1">
            Com base em {r.indicadores.filter(i => i.status !== "indisponivel").length} indicadores
          </p>
        </div>
      </div>

      <div className="p-5">
        <div className="flex justify-between text-[10.5px] uppercase tracking-wide text-tinta-suave mb-2">
          <span>Muito esticada</span><span>Valor justo</span><span>Muito descontada</span>
        </div>
        <div className="relative h-2 bg-linha rounded-full overflow-hidden">
          <div className="absolute h-full w-full rounded-full" style={{ background: "linear-gradient(90deg,#8a2f2f 0%,#9c5a2e 30%,#a9822f 50%,#2f4d3f 75%,#2f4d3f 100%)" }} />
          <div className="absolute top-1/2 w-3 h-3 bg-white border-2 border-tinta rounded-full" style={{ left: `${pos}%`, transform: "translate(-50%,-50%)" }} />
        </div>
        {r.margemSeguranca !== null && (
          <p className="text-[12px] text-tinta-suave mt-3 text-center">
            Margem de segurança de <strong className="tabular text-tinta">{r.margemSeguranca.toFixed(1)}%</strong> sobre o preço justo consolidado
          </p>
        )}
      </div>
    </div>
  );
}

function MetodosCard({ metodos }: { metodos: ResultadoMetodo[] }) {
  return (
    <div className="border border-linha bg-white divide-y divide-linha">
      {metodos.map(m => (
        <div key={m.metodo} className="p-5 flex flex-wrap items-center justify-between gap-3">
          <div className="max-w-md">
            <p className="text-[13px] font-medium mb-0.5">{m.metodo}</p>
            <p className="text-[12px] text-tinta-suave">{m.disponivel ? m.descricao : m.motivoIndisponivel}</p>
          </div>
          <div className="text-right">
            <p className="text-[17px] font-medium tabular">{m.disponivel ? moeda(m.valorJusto) : "—"}</p>
            {m.disponivel && m.upside !== null && (
              <p className={`text-[12px] tabular mt-0.5 ${m.upside >= 0 ? "text-selo" : "text-risco"}`}>{pct(m.upside)}</p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function IndicadoresGrid({ indicadores }: { indicadores: IndicadorAnalise[] }) {
  return (
    <div className="grid sm:grid-cols-2 gap-px bg-linha border border-linha">
      {indicadores.map(ind => (
        <div key={ind.chave} className="bg-white p-5">
          <div className="flex items-start justify-between gap-2 mb-2">
            <p className="text-[12.5px] font-medium leading-snug">{ind.titulo}</p>
            <span className={`text-[10.5px] font-medium px-2 py-0.5 whitespace-nowrap ${ST[ind.status]}`}>{ST_LABEL[ind.status]}</span>
          </div>
          <p className="text-[20px] font-medium tabular mb-1">{fmt(ind.valor, ind.unidade)}</p>
          <p className="text-[11px] text-tinta-suave mb-1.5">{ind.referencia}</p>
          <p className="text-[12px] text-tinta-suave leading-relaxed">{ind.comentario}</p>
        </div>
      ))}
    </div>
  );
}

function Parecer({ r }: { r: ResultadoValuation }) {
  const data = new Date(r.ativo.atualizadoEm).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  return (
    <div className="border border-linha bg-white p-6">
      <div className="flex items-center gap-2.5 mb-5 pb-5 border-b border-linha">
        <div className="w-8 h-8 flex items-center justify-center bg-tinta text-papel text-[10px] font-medium rounded-full">AV</div>
        <div>
          <p className="text-[13px] font-medium">Parecer fundamentalista</p>
          <p className="text-[11.5px] text-tinta-suave">Metodologia quantitativa · Atualizado em {data}</p>
        </div>
      </div>
      <p className="font-editorial text-[16px] leading-[1.8] border-l-2 border-selo pl-4">{r.parecer}</p>
      {(r.pontosFortes.length > 0 || r.pontosAtencao.length > 0) && (
        <div className="grid sm:grid-cols-2 gap-6 mt-6 pt-6 border-t border-linha">
          {r.pontosFortes.length > 0 && (
            <div>
              <p className="text-[10.5px] uppercase tracking-wide text-selo mb-2">Pontos favoráveis</p>
              {r.pontosFortes.map((p, i) => (
                <p key={i} className="text-[12.5px] text-tinta-suave leading-relaxed flex gap-2 mb-1.5"><span className="text-selo">＋</span>{p}</p>
              ))}
            </div>
          )}
          {r.pontosAtencao.length > 0 && (
            <div>
              <p className="text-[10.5px] uppercase tracking-wide text-alerta mb-2">Pontos de atenção</p>
              {r.pontosAtencao.map((p, i) => (
                <p key={i} className="text-[12.5px] text-tinta-suave leading-relaxed flex gap-2 mb-1.5"><span className="text-alerta">−</span>{p}</p>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Anuncio() {
  return (
    <div className="border border-dashed border-linha-forte flex items-center justify-center text-[11px] text-tinta-suave uppercase tracking-wide my-8" style={{ minHeight: "90px" }}>
      Publicidade
    </div>
  );
}

export default async function PaginaAtivo({ params }: { params: { ticker: string } }) {
  let resultado: ResultadoValuation;

  try {
    const ativo = await buscarAtivo(params.ticker);
    resultado = calcularValuation(ativo);
  } catch (erro) {
    const msg = erro instanceof AtivoNaoEncontradoError
      ? `Ticker "${params.ticker.toUpperCase()}" não encontrado na B3.`
      : erro instanceof Error ? erro.message : "Erro ao buscar dados.";
    return (
      <div className="max-w-2xl mx-auto px-5 py-16 text-center">
        <p className="font-editorial text-[22px] mb-3">Não foi possível carregar {params.ticker.toUpperCase()}</p>
        <p className="text-[14px] text-tinta-suave mb-8 leading-relaxed">{msg}</p>
        <a href="/" className="text-[13px] px-5 py-2.5 bg-selo text-white hover:bg-selo-hover transition-colors">
          Voltar ao início
        </a>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-5 py-10">
      <div className="mb-6">
        <form onSubmit={(e) => { e.preventDefault(); }} className="flex gap-2 max-w-xs">
          <input
            type="text" placeholder="Outro ticker..." maxLength={7}
            className="flex-1 text-[13px] px-3 py-1.5 bg-white border border-linha-forte focus:outline-none focus:border-selo tabular"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                const v = (e.target as HTMLInputElement).value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
                if (v.length >= 4) window.location.href = `/acao/${v}`;
              }
            }}
          />
          <a href="/" className="text-[12px] px-3 py-1.5 bg-papel border border-linha text-tinta-suave hover:border-selo transition-colors">← Início</a>
        </form>
      </div>

      <Painel r={resultado} />
      <Anuncio />

      <h2 className="font-editorial text-[20px] mb-4">Métodos de valuation aplicados</h2>
      <MetodosCard metodos={resultado.metodos} />

      <h2 className="font-editorial text-[20px] mb-4 mt-10">Indicadores fundamentalistas</h2>
      <IndicadoresGrid indicadores={resultado.indicadores} />

      <h2 className="font-editorial text-[20px] mb-4 mt-10">Parecer fundamentalista</h2>
      <Parecer r={resultado} />
      <Anuncio />
    </div>
  );
}

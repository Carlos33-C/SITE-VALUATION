import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-linha mt-16">
      <div className="max-w-5xl mx-auto px-5 py-10">
        <div className="grid sm:grid-cols-3 gap-8 text-[13px]">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="w-2 h-2 bg-selo inline-block" />
              <span className="font-editorial text-[16px]">Análise de Valuation</span>
            </div>
            <p className="text-tinta-suave leading-relaxed max-w-xs">
              Valuation fundamentalista de ações da B3, calculado a partir de
              dados públicos de mercado.
            </p>
          </div>

          <div>
            <p className="text-tinta-suave uppercase tracking-wide text-[11px] mb-3">
              Metodologia
            </p>
            <ul className="space-y-2 text-tinta-suave">
              <li><Link href="/o-que-e-valuation" className="hover:text-selo transition-colors">O que é valuation</Link></li>
              <li><Link href="/formula-de-graham" className="hover:text-selo transition-colors">Fórmula de Graham</Link></li>
              <li><Link href="/metodo-bazin" className="hover:text-selo transition-colors">Método de Bazin</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-tinta-suave uppercase tracking-wide text-[11px] mb-3">
              Institucional
            </p>
            <ul className="space-y-2 text-tinta-suave">
              <li><Link href="/politica-de-privacidade" className="hover:text-selo transition-colors">Política de privacidade</Link></li>
              <li><Link href="/termos-de-uso" className="hover:text-selo transition-colors">Termos de uso</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-linha mt-8 pt-6">
          <p className="text-[11.5px] text-tinta-suave leading-relaxed max-w-3xl">
            As informações apresentadas têm caráter exclusivamente informativo e educacional.
            Não constituem recomendação de compra ou venda de nenhum ativo. Consulte um
            profissional certificado antes de investir.
          </p>
          <p className="text-[11.5px] text-tinta-suave mt-3">
            © {new Date().getFullYear()} Análise de Valuation.
          </p>
        </div>
      </div>
    </footer>
  );
}
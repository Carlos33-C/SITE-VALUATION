"use client";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

const TICKERS_SUGERIDOS = ["PETR4", "VALE3", "ITUB4", "WEGE3", "BBAS3"];

export default function BuscaTicker({ tamanho = "grande" }: { tamanho?: "grande" | "compacto" }) {
  const router = useRouter();
  const [valor, setValor] = useState("");
  const [erro, setErro] = useState<string | null>(null);

  function irParaTicker(ticker: string) {
    const limpo = ticker.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (limpo.length < 4) { setErro("Digite um ticker válido, como PETR4."); return; }
    setErro(null);
    router.push(`/acao/${limpo}`);
  }

  function aoSubmeter(e: FormEvent) {
    e.preventDefault();
    irParaTicker(valor);
  }

  if (tamanho === "compacto") {
    return (
      <form onSubmit={aoSubmeter} className="flex items-center gap-2">
        <input
          type="text" value={valor} onChange={(e) => setValor(e.target.value)}
          placeholder="Ticker (ex: VALE3)" maxLength={7}
          className="w-full text-[13px] px-3 py-1.5 bg-white border border-linha-forte focus:outline-none focus:border-selo tabular"
        />
        <button type="submit" className="text-[12px] px-3 py-1.5 bg-selo text-white hover:bg-selo-hover transition-colors whitespace-nowrap">
          Analisar
        </button>
      </form>
    );
  }

  return (
    <div>
      <form onSubmit={aoSubmeter} className="flex flex-col sm:flex-row gap-2.5 max-w-lg">
        <input
          type="text" value={valor} onChange={(e) => setValor(e.target.value)}
          placeholder="Digite o ticker — ex: PETR4" maxLength={7} autoFocus
          className="flex-1 text-[16px] px-4 py-3 bg-white border border-linha-forte focus:outline-none focus:border-selo tabular"
        />
        <button type="submit" className="text-[14px] font-medium px-6 py-3 bg-selo text-white hover:bg-selo-hover transition-colors whitespace-nowrap">
          Analisar ação
        </button>
      </form>
      {erro && <p className="text-[13px] text-risco mt-2">{erro}</p>}
      <div className="flex flex-wrap gap-2 mt-4">
        {TICKERS_SUGERIDOS.map((t) => (
          <button key={t} onClick={() => irParaTicker(t)}
            className="text-[12px] tabular px-2.5 py-1 border border-linha text-tinta-suave hover:border-selo hover:text-selo transition-colors">
            {t}
          </button>
        ))}
      </div>
    </div>
  );
}
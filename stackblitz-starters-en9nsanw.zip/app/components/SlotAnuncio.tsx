export default function SlotAnuncio({
  formato = "horizontal",
  rotulo = "Publicidade",
}: {
  formato?: "horizontal" | "quadrado" | "vertical";
  rotulo?: string;
}) {
  const alturas: Record<string, string> = {
    horizontal: "90px",
    quadrado: "250px",
    vertical: "600px",
  };

  return (
    <div
      className="border border-dashed border-linha-forte flex items-center justify-center text-[11px] text-tinta-suave uppercase tracking-wide"
      style={{ minHeight: alturas[formato] }}
      role="complementary"
      aria-label="Espaço publicitário"
    >
      {rotulo}
    </div>
  );
}
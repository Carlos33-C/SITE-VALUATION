export default function PoliticaPrivacidade() {
  return (
    <div className="max-w-3xl mx-auto px-5 py-12">
      <div className="mb-12">
        <p className="text-[12px] uppercase tracking-wide text-tinta-suave mb-4">Informações legais</p>
        <h1 className="font-editorial text-[40px] sm:text-[48px] leading-[1.15] mb-5">Política de Privacidade</h1>
        <p className="text-[13px] text-tinta-suave">Última atualização: {new Date().toLocaleDateString("pt-BR")}</p>
      </div>

      <div className="space-y-10">
        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">1. Introdução</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Este site ("Análise de Valuation") respeita sua privacidade e está comprometido com a proteção de seus dados pessoais. Esta Política de Privacidade explica como coletamos, usamos e protegemos as informações que você fornece ao usar nosso site.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">2. Dados que coletamos</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Nós coletamos dados de duas formas:
          </p>
          <p className="text-[14px] text-tinta-suave mb-2"><strong className="text-tinta">Dados que você fornece:</strong> Se você nos contatar ou deixar um comentário, podemos coletar seu nome, email ou outras informações que você voluntariamente compartilhar.</p>
          <p className="text-[14px] text-tinta-suave"><strong className="text-tinta">Dados coletados automaticamente:</strong> Quando você visita o site, nós coletamos informações sobre seu dispositivo, navegador, endereço IP, páginas visitadas e tempo gasto — através de cookies e ferramentas de análise como Google Analytics.</p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">3. Como usamos seus dados</h2>
          <p className="text-[14px] text-tinta-suave mb-2">Usamos os dados coletados para:</p>
          <ul className="space-y-2 text-[14px] text-tinta-suave">
            <li>• Melhorar o conteúdo e a funcionalidade do site</li>
            <li>• Entender como você usa o site (através de analytics)</li>
            <li>• Mostrar anúncios personalizados (via Google AdSense)</li>
            <li>• Responder suas perguntas ou solicitações</li>
            <li>• Cumprir obrigações legais</li>
          </ul>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">4. Google AdSense e cookies de publicidade</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Este site usa Google AdSense para exibir anúncios. O Google usa cookies para servir anúncios baseados no seu histórico de navegação. Você pode desativar cookies personalizados visitando as preferências de privacidade do Google.
          </p>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Os anúncios podem incluir rastreamento de conversão. Isso significa que o Google rastreia se você clicou em um anúncio e completou uma ação no site do anunciante.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">5. Google Analytics</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Usamos Google Analytics para entender como você usa o site. Google Analytics coleta dados como:
          </p>
          <ul className="space-y-1 text-[14px] text-tinta-suave mb-3">
            <li>• Que páginas você visitou</li>
            <li>• Quanto tempo passou em cada página</li>
            <li>• De que país você está visitando</li>
            <li>• Que dispositivo você usa</li>
          </ul>
          <p className="text-[14px] text-tinta-suave">
            Esses dados são compartilhados com o Google. Para mais informações, veja a <a href="https://policies.google.com/privacy" className="text-selo hover:underline">Política de Privacidade do Google</a>.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">6. Dados de APIs externas (brapi.dev)</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Os dados de cotações de ações (preço, LPA, dividendos) vêm da API brapi.dev. Quando você busca uma ação, nós fazemos uma requisição para a API brapi.dev, que pode coletar informações sobre seu acesso.
          </p>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Recomendamos revisar a <a href="https://brapi.dev" className="text-selo hover:underline">política de privacidade do brapi.dev</a> para entender como seus dados são tratados por eles.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">7. Cookies</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed mb-3">
            Um cookie é um pequeno arquivo armazenado no seu navegador. Nós usamos cookies para:
          </p>
          <ul className="space-y-2 text-[14px] text-tinta-suave mb-3">
            <li>• Lembrar suas preferências</li>
            <li>• Rastrear sua atividade de navegação (Google Analytics)</li>
            <li>• Servir anúncios personalizados (Google AdSense)</li>
          </ul>
          <p className="text-[14px] text-tinta-suave">
            Você pode desativar cookies no seu navegador a qualquer momento. Isso pode limitar a funcionalidade do site.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">8. Lei Geral de Proteção de Dados (LGPD)</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Este site está em conformidade com a LGPD (Lei Geral de Proteção de Dados do Brasil). Você tem o direito de: acessar seus dados, corrigir dados incorretos, solicitar a exclusão de seus dados, e se opor ao processamento de seus dados. Para exercer esses direitos, entre em contato conosco.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">9. Segurança</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Nós implementamos medidas técnicas e organizacionais para proteger seus dados contra acesso não autorizado, alteração ou destruição. No entanto, nenhuma transmissão de dados pela internet é 100% segura, então não podemos garantir segurança absoluta.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">10. Retenção de dados</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Retemos dados coletados apenas pelo tempo necessário para os fins descritos nesta política, ou conforme exigido por lei. Cookies de publicidade e analytics são retidos de acordo com as políticas do Google.
          </p>
        </div>

        <div className="border-b border-linha pb-8">
          <h2 className="font-editorial text-[24px] mb-4">11. Links para terceiros</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Este site pode conter links para sites de terceiros. Não somos responsáveis por suas políticas de privacidade. Recomendamos revisar a política de privacidade de qualquer site antes de compartilhar informações pessoais.
          </p>
        </div>

        <div className="pb-8">
          <h2 className="font-editorial text-[24px] mb-4">12. Contato</h2>
          <p className="text-[15px] text-tinta-suave leading-relaxed">
            Se você tiver dúvidas sobre esta Política de Privacidade, entre em contato conosco através do formulário de contato no site ou envie um email para o endereço listado na seção "Sobre".
          </p>
        </div>
      </div>
    </div>
  );
}
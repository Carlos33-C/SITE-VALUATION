export default function MetodoBazin() {
  return (
    <div className="max-w-3xl mx-auto px-5 py-12">
      <div className="mb-12">
        <p className="text-[12px] uppercase tracking-wide text-selo mb-4">Metodologia</p>
        <h1 className="font-editorial text-[40px] sm:text-[48px] leading-[1.15] mb-5">Método de Bazin</h1>
        <p className="text-[16px] text-tinta-suave leading-relaxed max-w-2xl">
          Criado pelo investidor brasileiro Décio Bazin, este método é especialmente popular entre quem investe em ações que pagam dividendos altos. É a ferramenta do investidor de renda.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">A fórmula</h2>
        <div className="bg-papel border border-linha p-6 mb-6">
          <p className="text-[13px] text-tinta-suave mb-3">Preço-teto = Dividendo anual ÷ 6%</p>
          <p className="text-[12px] text-tinta-suave">
            Ou em forma percentual: Preço-teto = (Dividend Yield anual ÷ 6) × Preço atual
          </p>
        </div>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          A ideia é simples: você coloca seu dinheiro em um fundo de renda fixa que rende 6% ao ano. Para comprar uma ação ao invés disso, ela precisa pagar *pelo menos* 6% de dividendo. Se pagar mais, está barata. Se pagar menos, está cara.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Por que 6%?</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Bazin escolheu 6% como referência porque, na época, era aproximadamente o retorno de um título de renda fixa de qualidade. A lógica: "Por que eu compraria uma ação arriscada se pudesse ganhar 6% seguro em um fundo?"
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Hoje, a Selic (taxa básica de juros do Brasil) muda sempre. Então o número de referência deveria mudar também. Se a Selic está em 10%, talvez você exija 10% de dividend yield. Se está em 4%, talvez 5% seja suficiente.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          O ponto é: use um número que faça sentido *no contexto de juros de hoje*. O site usa 6% como padrão, mas você pode (e deve) ajustar baseado na taxa de juros vigente.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Exemplo prático</h2>
        <div className="bg-papel border border-linha p-6 mb-6">
          <p className="text-[13px] font-medium mb-3">Hipótese:</p>
          <p className="text-[13px] text-tinta-suave mb-2">Dividendo anual pagou: R$ 3,50</p>
          <p className="text-[13px] text-tinta-suave mb-4">Você exige um yield mínimo de: 6%</p>
          <p className="text-[13px] font-medium mb-2">Cálculo:</p>
          <p className="text-[13px] text-tinta-suave mb-2">Preço-teto = R$ 3,50 ÷ 0,06</p>
          <p className="text-[13px] text-tinta-suave mb-4">= R$ 58,33</p>
          <p className="text-[12px] text-tinta-suave border-t border-linha pt-4">
            Logo, você não deveria pagar mais de R$ 58,33 por essa ação, porque assim estaria garantindo um yield de pelo menos 6%.
          </p>
        </div>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Para quem é o método de Bazin?</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Bazin é perfeito para:
        </p>
        <ul className="space-y-2 mb-6">
          <li className="flex gap-3">
            <span className="text-selo">+</span>
            <span className="text-[14px] text-tinta-suave"><strong>Investidores de renda.</strong> Quem vive de dividendos e precisa de fluxo de caixa previsível.</span>
          </li>
          <li className="flex gap-3">
            <span className="text-selo">+</span>
            <span className="text-[14px] text-tinta-suave"><strong>Aposentados.</strong> Quem precisa retirar dinheiro periodicamente da bolsa.</span>
          </li>
          <li className="flex gap-3">
            <span className="text-selo">+</span>
            <span className="text-[14px] text-tinta-suave"><strong>Conservadores.</strong> Quem prefere ganhar dividendo a contar com valorização da ação.</span>
          </li>
          <li className="flex gap-3">
            <span className="text-selo">+</span>
            <span className="text-[14px] text-tinta-suave"><strong>Investidores em setores específicos.</strong> Bancos, utilities (água, energia), fundos imobiliários — todos tendem a pagar dividendos altos.</span>
          </li>
        </ul>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          Não é bom para startups ou empresas em crescimento — elas praticamente não pagam dividendos. Nesse caso, use Graham ou DCF.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Armadilhas comuns</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          <strong className="text-tinta">1. Dividend extraordinário.</strong> Às vezes uma empresa paga um dividendo gigante — uma única vez — por que vendeu um ativo. Se você usar esse número para calcular Bazin, vai subestimar bastante o preço. Sempre verifique se o dividendo é recorrente.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          <strong className="text-tinta">2. Empresa em apuros.</strong> Uma empresa pode pagar dividend yield de 15% porque está indo à falência — os acionistas sabem que não vão receber muito mais. Dividend alto não é sempre bom sinal.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          <strong className="text-tinta">3. Taxa de referência desatualizada.</strong> Se você está usando 6% porque ouviu falar disso em 2015, e hoje a Selic está em 10%, você está sendo muito otimista. Atualize a taxa de referência regularmente.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          <strong className="text-tinta">4. Não investigar a qualidade.</strong> Uma ação barata pode ser barata porque a empresa está ruim. Sempre leia o balanço, conheça o negócio, verifique se o dividend é sustentável.
        </p>
      </div>

      <div className="pb-12">
        <h2 className="font-editorial text-[28px] mb-5">Próximos passos</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <a href="/formula-de-graham" className="group border border-linha hover:border-selo transition-colors p-5">
            <p className="text-[14px] font-medium mb-1 group-hover:text-selo transition-colors">Anterior: Fórmula de Graham</p>
            <p className="text-[13px] text-tinta-suave">Para empresas com patrimônio forte.</p>
          </a>
          <a href="/o-que-e-valuation" className="group border border-linha hover:border-selo transition-colors p-5">
            <p className="text-[14px] font-medium mb-1 group-hover:text-selo transition-colors">Revisar: O que é valuation</p>
            <p className="text-[13px] text-tinta-suave">Entenda o panorama geral.</p>
          </a>
        </div>
        <div className="mt-6">
          <a href="/" className="text-[13px] px-5 py-2.5 bg-selo text-white hover:bg-selo-hover transition-colors inline-block">
            Analisar uma ação
          </a>
        </div>
      </div>
    </div>
  );
}
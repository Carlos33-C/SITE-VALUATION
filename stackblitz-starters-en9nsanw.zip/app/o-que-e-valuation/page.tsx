export default function OQueEValuation() {
  return (
    <div className="max-w-3xl mx-auto px-5 py-12">
      <div className="mb-12">
        <p className="text-[12px] uppercase tracking-wide text-selo mb-4">Guia educativo</p>
        <h1 className="font-editorial text-[40px] sm:text-[48px] leading-[1.15] mb-5">O que é valuation?</h1>
        <p className="text-[16px] text-tinta-suave leading-relaxed max-w-2xl">
          Valuation é o processo de estimar o valor intrínseco de uma empresa. É diferente do preço da ação — que é o que você paga no mercado. O valor justo é o que você *deveria* pagar, em teoria, baseado em fundamentos.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Preço vs. Valor</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Preço é o que você vê na bolsa todos os dias — é a opinião coletiva do mercado *neste momento*. Valor é o que a empresa vale *de verdade*, baseado em seus fundamentos: lucros, patrimônio, fluxo de caixa e crescimento esperado.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Um bom investidor busca empresas onde o preço está abaixo do valor — desconto. Um mau investidor compra quando o preço está acima do valor — prêmio — e torce para que o mercado concorde com ele.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          Valuation é a ferramenta que ajuda você a calcular esse valor e decidir se uma ação está cara ou barata.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Por que valuation importa?</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Sem valuation, você está especulando. Está apostando que o preço vai subir amanhã porque subiu hoje — aquilo que os investidores chamam de "momentum investing" ou, na verdade, palpite.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Com valuation, você tem uma âncora. Você sabe: "Esta ação está 30% mais barata que seu valor justo. Tenho margem de segurança." Ou o oposto: "Esta ação está 50% mais cara que seu valor justo. O risco é alto."
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          Valuation é como ter um mapa numa terra desconhecida. Não é 100% preciso, mas é imensamente melhor que andar no escuro.
        </p>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Como funciona a valuation?</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-6">
          Existem muitas metodologias — desde a simples (comparar com empresas similares) até a complexa (modelar fluxos de caixa 20 anos no futuro). Aqui no site, usamos quatro das mais populares:
        </p>

        <div className="space-y-6">
          <div className="pl-4 border-l-2 border-selo">
            <p className="text-[14px] font-medium mb-2">Fórmula de Graham</p>
            <p className="text-[14px] text-tinta-suave leading-relaxed">
              Uma das mais antigas, criada por Benjamin Graham (mentor de Warren Buffett). Usa apenas dois números: lucro por ação e valor patrimonial por ação. Simples, objetiva, e funciona bem para empresas com ciclos de negócio estáveis.
            </p>
          </div>

          <div className="pl-4 border-l-2 border-selo">
            <p className="text-[14px] font-medium mb-2">Método de Bazin</p>
            <p className="text-[14px] text-tinta-suave leading-relaxed">
              Criado pelo investidor brasileiro Décio Bazin, funciona especialmente bem para ações que pagam dividendos altos e consistentes. É o método preferido de quem investe para renda.
            </p>
          </div>

          <div className="pl-4 border-l-2 border-selo">
            <p className="text-[14px] font-medium mb-2">P/L de Referência</p>
            <p className="text-[14px] text-tinta-suave leading-relaxed">
              A mais intuitiva. Você pega o lucro por ação, multiplica por um múltiplo "justo" (histórico ou de peers), e tem uma estimativa rápida.
            </p>
          </div>

          <div className="pl-4 border-l-2 border-selo">
            <p className="text-[14px] font-medium mb-2">DCF (Fluxo de Caixa Descontado)</p>
            <p className="text-[14px] text-tinta-suave leading-relaxed">
              A mais sofisticada. Projeta o fluxo de caixa futuro da empresa, desconta para valor presente usando uma taxa de juros, e chega a um valor. É a mais usada por analistas profissionais, mas também a mais dependente de premissas.
            </p>
          </div>
        </div>
      </div>

      <div className="border-b border-linha pb-12 mb-12">
        <h2 className="font-editorial text-[28px] mb-5">Limitações de qualquer valuation</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Valuation não é previsão do futuro. É uma estimativa baseada em dados passados e premissas sobre o futuro. E premissas podem estar erradas.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-4">
          Uma empresa pode ter lucro deprimido por um ano ruim — então P/L vai estar artificialmente alto, e métodos baseados em lucro vão subestimar valor. Ou pode ter um dividend extraordinário que não vai se repetir — então um ano que você calcula Bazin sai errado.
        </p>
        <p className="text-[15px] text-tinta-suave leading-relaxed">
          Por isso, a melhor valuation nunca é um número único. É uma faixa, com uma margem de segurança. E sempre com disclaimers de que você investigou por que os diferentes métodos chegam a respostas diferentes.
        </p>
      </div>

      <div className="pb-12">
        <h2 className="font-editorial text-[28px] mb-5">Próximos passos</h2>
        <p className="text-[15px] text-tinta-suave leading-relaxed mb-6">
          Agora que você entende o conceito, explore as metodologias individuais:
        </p>
        <div className="grid sm:grid-cols-2 gap-4">
          <a href="/formula-de-graham" className="group border border-linha hover:border-selo transition-colors p-5">
            <p className="text-[14px] font-medium mb-1 group-hover:text-selo transition-colors">Fórmula de Graham</p>
            <p className="text-[13px] text-tinta-suave">Entenda a fórmula clássica passo a passo.</p>
          </a>
          <a href="/metodo-bazin" className="group border border-linha hover:border-selo transition-colors p-5">
            <p className="text-[14px] font-medium mb-1 group-hover:text-selo transition-colors">Método de Bazin</p>
            <p className="text-[13px] text-tinta-suave">Para quem investe em dividendos.</p>
          </a>
        </div>
        <div className="mt-6">
          <a href="/" className="text-[13px] px-5 py-2.5 bg-selo text-white hover:bg-selo-hover transition-colors inline-block">
            Voltar à análise de ações
          </a>
        </div>
      </div>
    </div>
  );
}
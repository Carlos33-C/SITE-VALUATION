export default function NotFound() {
  return (
    <div className="max-w-2xl mx-auto px-5 py-20 text-center min-h-[60vh] flex flex-col items-center justify-center">
      <div className="mb-8">
        <p className="text-[64px] font-medium text-linha mb-2">404</p>
        <h1 className="font-editorial text-[32px] sm:text-[40px] mb-3">Página não encontrada</h1>
        <p className="text-[16px] text-tinta-suave max-w-md mx-auto leading-relaxed">
          A página que você está procurando não existe ou foi movida. Vamos voltar ao início?
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
        <a href="/" className="text-[14px] px-6 py-3 bg-selo text-white hover:bg-selo-hover transition-colors">
          Voltar ao início
        </a>
        <form action="" onSubmit={(e) => {
          e.preventDefault();
          const input = (e.target as HTMLFormElement).querySelector('input') as HTMLInputElement;
          const ticker = input.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
          if (ticker.length >= 4) window.location.href = `/acao/${ticker}`;
        }} className="flex gap-2">
          <input
            type="text"
            placeholder="Digite um ticker..."
            maxLength={7}
            className="text-[13px] px-4 py-3 border border-linha-forte focus:outline-none focus:border-selo tabular"
          />
          <button type="submit" className="text-[13px] px-4 py-3 bg-papel border border-linha text-tinta-suave hover:border-selo transition-colors whitespace-nowrap">
            Analisar
          </button>
        </form>
      </div>

      <div className="mt-12 pt-8 border-t border-linha">
        <p className="text-[12px] uppercase tracking-wide text-tinta-suave mb-4">Conteúdo popular</p>
        <div className="grid sm:grid-cols-2 gap-3">
          <a href="/o-que-e-valuation" className="text-[13px] text-tinta-suave hover:text-selo transition-colors">
            → O que é valuation
          </a>
          <a href="/formula-de-graham" className="text-[13px] text-tinta-suave hover:text-selo transition-colors">
            → Fórmula de Graham
          </a>
          <a href="/metodo-bazin" className="text-[13px] text-tinta-suave hover:text-selo transition-colors">
            → Método de Bazin
          </a>
          <a href="/politica-de-privacidade" className="text-[13px] text-tinta-suave hover:text-selo transition-colors">
            → Política de privacidade
          </a>
        </div>
      </div>
    </div>
  );
}